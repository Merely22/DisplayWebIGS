import pandas as pd
from datetime import datetime
import requests
from io import StringIO
def descargar_summary(anio):
    url = f"https://cddis.nasa.gov/archive/gnss/data/highrate/{anio}/hrv{str(anio)[2:]}_summary.{anio}"
    r = requests.get(url)
    r.raise_for_status()
    return r.text
def parsear_summary(contenido_txt):
    columnas = [
        "Site", "Domes", "Start", "End", "Rec Type", 
        "Ant Type", "Approx Position", "Interval", "Format", "Mon Name"
    ]
    df = pd.read_csv(
        StringIO(contenido_txt),
        sep=r"\s+",
        comment="#",
        header=None,
        names=columnas,
        usecols=[0, 2, 3, 8]  # Site, Start, End, Format
    )
    # Convertir fechas
    df["Start"] = pd.to_datetime(df["Start"], errors="coerce", format="%Y-%m-%d")
    df["End"] = pd.to_datetime(df["End"], errors="coerce", format="%Y-%m-%d")
    # Crear diccionario indexado por nombre de estación (4 letras)
    summary_dict = {
        row["Site"].upper(): {
            "Start": row["Start"],
            "End": row["End"],
            "Format": str(row["Format"])  # Puede ser "2" o "3"
        }
        for _, row in df.iterrows()
    }
    return summary_dict

def verificar_disponibilidad_summary(sitename, fecha, summary_dict, csv_df):
    csv_df.columns = csv_df.columns.str.strip()
    nombre_corto = sitename[:4].upper()
    # Buscar fila del CSV local
    fila_csv = csv_df[csv_df["Site Name"].str.strip() == sitename.strip()]
    if fila_csv.empty:
        return False, "La estación no está en el CSV local."

    tiene_rate1s = fila_csv["Rate 1s"].values[0].strip().upper() == "SI"
    if not tiene_rate1s:
        return False, "La estación no tiene datos en 1s (según CSV local)."

    # Verificar si aparece en el archivo summary
    if nombre_corto not in summary_dict:
        return False, "La estación no está listada en el archivo summary del año seleccionado."

    info = summary_dict[nombre_corto]
    start, end = info["Start"], info["End"]
    if pd.isna(start) or pd.isna(end):
        return False, "Fechas inválidas en archivo summary."

    if not (start <= fecha <= end):
        return False, f"La fecha está fuera del rango válido ({start.date()} a {end.date()})."

    return True, f"✅ Datos 1s disponibles. Formato: RINEX v{info['Format']}"


def obtener_formato_rinex(sitename, summary_dict):
    nombre_corto = sitename[:4].upper()
    info = summary_dict.get(nombre_corto)
    if not info:
        return None
    return str(info["Format"])