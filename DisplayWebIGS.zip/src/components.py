import streamlit as st
import pandas as pd

def mostrar_info_estacion_resumida(sitename, summary_dict, csv_df):
    nombre_corto = sitename[:4].upper()

    info_summary = summary_dict.get(nombre_corto, {})
    info_csv = csv_df[csv_df["Site Name"] == sitename].iloc[0]

    data = {
        "ID Estación": nombre_corto,
        "Nombre completo": sitename,
        "Posición Aproximada": f"{info_csv['Latitude']:.6f}, {info_csv['Longitude']:.6f}",
        "Versión RINEX": info_summary.get("Format", "N/A"),
        "Intervalo (1s)": info_csv.get("Rate 1s", "N/A"),
        "Agencia": info_csv.get("Agency", "N/A"),
        "Constelaciones": info_csv.get("Constellation", "N/A")
    }

    st.markdown("### 📋 Resumen de estación seleccionada")
    st.dataframe(pd.DataFrame([data]))
